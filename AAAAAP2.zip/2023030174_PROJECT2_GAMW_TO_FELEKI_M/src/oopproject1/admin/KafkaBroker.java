package oopproject1.admin;

import java.util.ArrayList;

public class KafkaBroker {

	private String host;
	private int brokerId;
	private static int myBrokerId = 0;
	private int port;
	private ArrayList<KafkaTopic> topics;

	private int topicCount = 0;
	private int maxTopics;
	private int newPort;

	public KafkaBroker(String host, int port, int maxTopics) throws Exception {

		if (!isValidPort(port)) {
			throw new Exception("Invalid port");
		}

		if (!isValidHost(host)) {
			throw new Exception("Invalid host");
		}

		this.setBrokerId(myBrokerId);
		myBrokerId++;

		this.host = host;
		this.port = port;
		this.maxTopics = maxTopics;
		this.topics = new ArrayList<>(maxTopics);

		this.topicCount = 0;
	}

	private boolean isValidPort(int port) {
		return port >= 0 && port <= 65535;
	}

	private boolean isValidHost(String host) {
		String[] parts = host.split("\\.");

		if (parts.length != 4)
			return false;

		for (String part : parts) {
			int num = Integer.parseInt(part);
			if (num < 0 || num > 255)
				return false;
		}
		return true;
	}

	protected void addTopic(KafkaTopic topic) throws Exception {
		if (topicCount < maxTopics) {
			topics.add(topic);
			topicCount++;
		} else
			throw new Exception("topic Count cannot be more than Max topics");
	}

	protected void removeTopic(String topicName) throws Exception {
		for (int i = 0; i < topicCount; i++) {
			if (topics.get(i).getName().equals(topicName)) {
				topics.remove(i);
				topicCount--;
				return;
			}
		}
		throw new Exception("Topic " + topicName + " not found in the Kafka Cluster");
	}

	protected void listAllTopics() {
		listAllTopics(false);
	}

	/*
	 * protected void listAllTopics(boolean includeDetails) { if (topicCount == 0) {
	 * System.out.println("No topics found for broker " + host + ":" + port);
	 * return; } System.out.println("List of Topics from Broker " + host + ":" +
	 * port); for (int i = 0; i < topicCount; i++) { System.out.println("Topic " +
	 * (i + 1) + ": " + topics.get(i).getName()); KafkaTopic topic = topics.get(i);
	 * 
	 * if (includeDetails) { System.out.println("  Partitions: "); for (int j = 0; j
	 * < topic.getPartitions().size(); j++) { KafkaPartition partition =
	 * topic.getPartitions().get(j); System.out.println("    Partition " + (j + 1));
	 * System.out.println("      Replicas: "); for (int k = 0; k <
	 * partition.getReplicas().size(); k++) { KafkaReplica replica =
	 * partition.getReplicas().get(k); KafkaBroker broker =
	 * partition.getReplicas().get(k).getBroker(); System.out.println(
	 * "        Replica " + (k + 1) + ": " + broker.getHost() + ":" +
	 * broker.getPort()); if (replica != null) { broker = replica.getBroker(); } if
	 * (broker != null) {
	 * 
	 * System.out.println( "        Replica " + (k + 1) + ": " + broker.getHost() +
	 * ":" + broker.getPort()); } else {
	 * 
	 * System.out.println("        Replica " + (k + 1) + ": (Unknown broker)"); } }
	 * }
	 * 
	 * }
	 * 
	 * } }
	 */

	protected void listAllTopics(boolean includeDetails) {
		if (topicCount == 0) {
			System.out.println("No topics found for broker " + host + ":" + port);
			return;
		}
		System.out.println("List of Topics from Broker " + host + ":" + port);

		int topicIndex = 1;
		for (KafkaTopic topic : topics) {
			System.out.println("Topic " + topicIndex++ + ": " + topic.getName());

			if (includeDetails) {
				System.out.println("  Partitions: ");

				int partitionIndex = 1;
				for (KafkaPartition partition : topic.getPartitions()) {
					System.out.println("    Partition " + partitionIndex++);

					System.out.println("      Replicas: ");
					int replicaIndex = 1;

					for (KafkaReplica replica : partition.getReplicas()) {

						if (replica != null) {
							KafkaBroker broker = replica.getBroker();
							if (broker != null) {
								System.out.println("        Replica " + replicaIndex + ": " + broker.getHost() + ":"
										+ broker.getPort());
							} else {
								System.out.println("        Replica " + replicaIndex + ": (Unknown broker)");
							}
						} else {
							System.out.println("        Replica " + replicaIndex + ": (Unknown replica)");
						}

						replicaIndex++;
					}

				}
			}
		}

	}

	protected String getHost() {
		return host;
	}

	protected int getBrokerId() {
		return brokerId;
	}

	protected int getMyBrokerId() {
		return myBrokerId;
	}

	protected int getPort() {
		return port;
	}

	public void setPort(int port) throws Exception {
		this.port = port;
		if (!isValidPort(port)) {
			throw new Exception("Invalid port");
		}

	}

	public ArrayList<KafkaTopic> getTopics() {
		return topics;
	}

	public void setTopics(ArrayList<KafkaTopic> topics) {
		this.topics = topics;
	}

	public int getTopicCount() {
		return topicCount;
	}

	public void setTopicCount(int topicCount) {
		this.topicCount = topicCount;
	}

	public int getMaxTopics() {
		return maxTopics;
	}

	public int getNewPort() {
		return newPort;
	}

	public void setNewPort(int newPort) {
		this.newPort = newPort;
	}

	private void setBrokerId(int brokerId) {
		this.brokerId = brokerId;
	}

}
