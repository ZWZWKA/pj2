package oopproject1.admin;

import java.util.ArrayList;

public class KafkaCluster {

	private ArrayList<KafkaBroker> brokers;
	private static final int DEFAULT_MAX_BROKERS = 5;
	private static int brokerCount;
	private int maxBrokers;
	private int maxTopicsPerBroker;

	public KafkaCluster(int maxBrokers, int maxTopicsPerBroker) {
		this.maxBrokers = maxBrokers;
		this.maxTopicsPerBroker = maxTopicsPerBroker;
		this.brokers = new ArrayList<>(maxBrokers);

		KafkaCluster.brokerCount = 0;
	}

	public KafkaCluster(int maxTopicsPerBroker) {
		this(DEFAULT_MAX_BROKERS, maxTopicsPerBroker);
	}

	public void insertBroker(KafkaBroker broker) throws Exception {
		if (broker.getMaxTopics() > maxTopicsPerBroker) {
			throw new Exception("Max Topics of Broker cannot be more than: " + maxTopicsPerBroker);
		}
		if (brokerCount < maxBrokers) {
			for (KafkaBroker b : brokers) {
				if (b.getHost().equals(broker.getHost()) && b.getPort() == broker.getPort()) {
					throw new Exception("Broker with the same host and port already exists.");
				}
			}
			brokers.add(broker);
			brokerCount++;
		} else
			throw new Exception("Broker Count cannot be more than Max brokers");
	}

	public void removeBroker(String host, int port) throws Exception {
		for (int i = 0; i < brokerCount; i++) {
			if (brokers.get(i).getHost().equals(host) && brokers.get(i).getPort() == port) {
				brokers.remove(i);
				brokerCount--;
				System.out.println("Broker " + host + ":" + port
						+ " and its associated topics, partitions, and replicas removed successfully.");
				return;
			}
		}
		throw new Exception("Broker with host " + host + " and port " + port + " does not exist");
	}

	protected KafkaBroker findBrokerByHostAndPort(String host, int port) {
		for (KafkaBroker broker : brokers) {
			if (broker != null && broker.getHost().equals(host) && broker.getPort() == port) {
				return broker;
			}
		}
		return null;
	}

	public void updateBrokerPort(String host, int port, int newPort) throws Exception {
		KafkaBroker broker = findBrokerByHostAndPort(host, port);
		if (broker != null) {
			for (KafkaBroker b : brokers) {
				if (b != null && b.getHost().equals(host) && b.getPort() == newPort) {
					throw new Exception("Port " + newPort + " is already occupied");
				}
			}
			broker.setPort(newPort);
		} else {
			throw new Exception("Broker with Host: " + host + " and Port " + port + " doesn't exist");
		}
	}

	public void addTopic(String topicName, int numPartitions, int maxProducers, int maxConsumers, int replicationFactor,
			boolean keyed) throws Exception {

		if (replicationFactor > brokerCount) {
			throw new Exception("Replication factor cannot be greater than the number of brokers.");
		}

		int brokerIndex = 0;

		if (brokers.isEmpty()) {
			throw new Exception("At least one broker should be created before adding a topic");
		}

		for (int i = 0; i < brokerCount; i++) {
			if (brokers.get(i) != null) {
				if (brokers.get(i).getTopicCount() < brokers.get(brokerIndex).getTopicCount()) {
					brokerIndex = i;
				}

				for (KafkaTopic topic : brokers.get(i).getTopics()) {
					if (topic != null && topic.getName().equals(topicName)) {
						throw new Exception("Topic with name '" + topic.getName() + "' already exists in the cluster.");
					}
				}
			}
		}

		KafkaTopic topic = new KafkaTopic(topicName, numPartitions, brokers.get(brokerIndex), maxProducers,
				maxConsumers, replicationFactor, keyed);
		brokers.get(brokerIndex).addTopic(topic);
		for (int i = 0; i < numPartitions; i++) {
			KafkaPartition partition = new KafkaPartition(replicationFactor);
			topic.getPartitions().add(partition);

			int curIndex = brokerIndex;

			for (int j = 0; j < replicationFactor; j++) {

				curIndex = (curIndex + 1) % brokerCount;
				/*
				 * curIndex++; if (curIndex == brokerIndex) { curIndex++; } if
				 * (brokers.get(curIndex) == null || curIndex > brokerCount) { curIndex = 0; }
				 */

				KafkaReplica replica = new KafkaReplica(brokers.get(curIndex), partition);
				partition.getReplicas().set(j, replica);

			}
		}
	}

	public void deleteTopic(String topicName) throws Exception {
		KafkaTopic topic = findTopicByName(topicName);
		if (topic == null) {
			throw new Exception("Topic " + topicName + " not found in the Cluster");
		}
		topic.getOwner().removeTopic(topicName);
	}

	public KafkaTopic findTopicByName(String topicName) {
		for (KafkaBroker broker : brokers) {
			if (broker != null) {
				for (KafkaTopic topic : broker.getTopics()) {
					if (topic != null && topic.getName().equals(topicName)) {
						return topic;
					}
				}
			}
		}
		return null;
	}

	public void listAllBrokers() {
		System.out.println("List of Brokers:  ");
		System.out.println("brokerCount = " + brokerCount);
		for (KafkaBroker broker : brokers) {
			if (broker != null) {
				System.out.println("Broker : " + broker.getBrokerId());
				System.out.println("Host : " + broker.getHost());
				System.out.println("Port : " + broker.getPort());
				System.out.println("Topic Count : " + broker.getTopicCount() + "\n");
			}
		}
	}

	public void listAllTopicsAcrossBrokers(boolean includeDetails) {
		System.out.println("List of Topics across Brokers: ");
		for (KafkaBroker broker : brokers) {
			if (broker != null) {
				System.out.println("Broker  " + broker.getBrokerId() + ":");
				System.out.println("Host : " + broker.getHost());
				System.out.println("Port : " + broker.getPort());
				broker.listAllTopics(includeDetails);
			}
		}
	}

	public void listAllTopicsAcrossBrokers() {
		listAllTopicsAcrossBrokers(false);
	}

	public boolean checkBrokerExistence(String host, int port) {
		for (KafkaBroker broker : brokers) {
			if (broker != null && broker.getHost().equals(host) && broker.getPort() == port) {
				return true;
			}
		}
		return false;
	}

	public boolean checkTopicExistence(String topicName) {
		for (KafkaBroker broker : brokers) {
			if (broker != null) {
				for (KafkaTopic topic : broker.getTopics()) {
					if (topic != null && topic.getName().equals(topicName)) {
						return true;
					}
				}
			}
		}
		return false;
	}
}
