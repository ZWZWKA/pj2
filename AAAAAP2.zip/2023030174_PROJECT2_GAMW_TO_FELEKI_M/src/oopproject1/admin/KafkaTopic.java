package oopproject1.admin;

import java.util.ArrayList;

public class KafkaTopic {

	private String name;
	private KafkaBroker owner;
	protected ArrayList<KafkaPartition> partitions;
	private ArrayList<KafkaProducer> producers;
	private ArrayList<KafkaConsumer> consumers;
	private int replicationFactor;
	private boolean keyed;
	private int producerCount;
	private int consumerCount;
	private final static int DEFAULT_REPLICATION_FACTOR = 1;
	private final static boolean DEFAULT_KEYED = false;
	private final static int DEFAULT_MAX_PRODUCERS = 10;
	private final static int DEFAULT_MAX_CONSUMERS = 10;

	protected KafkaTopic(String name, int numPartitions, KafkaBroker owner, int maxProducers, int maxConsumers,
			int replicationFactor, boolean keyed) throws Exception {

		checkValidPositiveInteger(numPartitions);

		checkValidPositiveInteger(replicationFactor);

		this.name = name;
		this.owner = owner;
		this.partitions = new ArrayList<>(numPartitions);
		this.producers = new ArrayList<>(maxProducers);
		this.consumers = new ArrayList<>(maxConsumers);
		this.replicationFactor = replicationFactor;
		this.keyed = keyed;
		this.consumerCount = 0;
		this.producerCount = 0;
	}

	protected KafkaTopic(String name, int numPartitions, KafkaBroker owner, int maxProducers, int maxConsumers)
			throws Exception {

		this(name, numPartitions, owner, maxProducers, maxConsumers, DEFAULT_REPLICATION_FACTOR, DEFAULT_KEYED);
	}

	KafkaTopic(String name, int numPartitions, KafkaBroker owner, int replicationFactor, boolean keyed)
			throws Exception {
		this(name, numPartitions, owner, DEFAULT_MAX_PRODUCERS, DEFAULT_MAX_CONSUMERS, replicationFactor, keyed);

	}

	KafkaTopic(String name, int numPartitions, KafkaBroker owner) throws Exception {
		this(name, numPartitions, owner, DEFAULT_MAX_PRODUCERS, DEFAULT_MAX_CONSUMERS, DEFAULT_REPLICATION_FACTOR,
				DEFAULT_KEYED);
	}

	protected void addProducer(KafkaProducer producer) throws Exception {
		if (!producer.getTopic().getName().equals(name)) {
			throw new Exception("This producer was created for " + producer.getTopic().getName()
					+ " cannot add this producer to topic " + name);
		}
		if (producerCount < producers.size()) {
			producers.add(producer);
			producerCount++;
		} else
			throw new Exception("Producer Count cannot be more than Max producers");
	}

	protected void addConsumer(KafkaConsumer consumer) throws Exception {
		if (!consumer.getTopic().getName().equals(name)) {
			throw new Exception("This consumer was created for topic: " + consumer.getTopic().getName()
					+ "   cannot add this consumer to topic:  " + name);
		}
		if (consumerCount < consumers.size()) {
			consumers.add(consumer);
			consumerCount++;
		} else
			throw new Exception("Consumer Count cannot be more than Max consumers");
	}

	private void checkValidPositiveInteger(int parameter) throws Exception {
		if (parameter < 1) {
			throw new Exception("Parameter cannot be < 1");
		}

	}

	protected String getName() {
		return name;
	}

	protected void setName(String name) {
		this.name = name;
	}

	protected KafkaBroker getOwner() {
		return owner;
	}

	protected ArrayList<KafkaPartition> getPartitions() {
		return partitions;
	}

	protected ArrayList<KafkaProducer> getProducers() {
		return producers;
	}

	protected ArrayList<KafkaConsumer> getConsumers() {
		return consumers;
	}

	protected int getReplicationFactor() {
		return replicationFactor;
	}

	protected boolean isKeyed() {
		return keyed;
	}

	protected int getProducerCount() {
		return producerCount;
	}

	protected int getConsumerCount() {
		return consumerCount;
	}

}
