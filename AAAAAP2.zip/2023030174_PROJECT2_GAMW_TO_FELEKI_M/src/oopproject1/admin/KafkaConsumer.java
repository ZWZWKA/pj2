package oopproject1.admin;

public class KafkaConsumer extends KafkaClient {

	@Override
	public void sendMessage(String message) throws Exception {
		throw new Exception("Consumers can only receive messages");
	}

	@Override
	public String receiveMessage() {
		String message = "Received Message from topic: " + getTopic().getName();
		return message;

	}

	public KafkaConsumer(KafkaTopic topic) throws Exception {
		super(topic);
	}
}
