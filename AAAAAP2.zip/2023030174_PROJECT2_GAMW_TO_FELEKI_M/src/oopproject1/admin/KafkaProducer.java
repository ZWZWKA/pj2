package oopproject1.admin;

public class KafkaProducer extends KafkaClient {

	@Override
	public void sendMessage(String message) {
		System.out.println("Message sent to topic:" + getTopic().getName() + ", Message: " + message);
	}

	@Override
	public String receiveMessage() throws Exception {
		throw new Exception("Producers can only send messages");
	}

	public KafkaProducer(KafkaTopic topic) throws Exception {
		super(topic);

	}
}
