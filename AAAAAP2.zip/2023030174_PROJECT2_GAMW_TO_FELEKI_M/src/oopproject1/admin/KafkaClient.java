package oopproject1.admin;

public abstract class KafkaClient {

	private KafkaTopic topic;

	public abstract void sendMessage(String message) throws Exception;

	public abstract String receiveMessage() throws Exception;

	public KafkaClient(KafkaTopic topic) {
		this.topic = topic;
	}

	public KafkaTopic getTopic() {
		return topic;
	}

	public void setTopic(KafkaTopic topic) {
		this.topic = topic;
	}
}
