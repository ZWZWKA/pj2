package oopproject1.admin;

import java.util.ArrayList;

public class KafkaPartition {

	private static final long DEFAULT_OFFSET = 0;
	private long offset;
	protected ArrayList<KafkaReplica> replicas;
	private static final int DEFAULT_NUM_REPLICAS = 3;

	public KafkaPartition(int numReplicas) {
		this.offset = DEFAULT_OFFSET;
		this.replicas = new ArrayList<>(numReplicas);
		for (int i = 0; i < numReplicas; i++) {
			this.replicas.add(null);
		}
	}

	public KafkaPartition() {
		this.offset = DEFAULT_OFFSET;
		this.replicas = new ArrayList<>(DEFAULT_NUM_REPLICAS);
		for (int i = 0; i < DEFAULT_NUM_REPLICAS; i++) {
			this.replicas.add(null);
		}
	}

	public long getOffset() {
		return offset;
	}

	public void setOffset(long offset) throws Exception {
		if (offset < 0) {
			throw new Exception("Illegal input. Offset cannot be negative ");
		}
		this.offset = offset;
	}

	public ArrayList<KafkaReplica> getReplicas() {
		return replicas;
	}

	public void setReplicas(ArrayList<KafkaReplica> replicas) {
		this.replicas = replicas;
	}
}
